<?php 

    header('X-Frame-Options: DENY');
    header('X-XSS-Protection: 1; mode=block');
    header('X-Content-Type-Options: nosniff');

    session_start();

    // if(isset($_SESSION['LAST_ACTIVE_TIME'])){
    //     if((time()-$_SESSION['LAST_ACTIVE_TIME'])>10){
    //         header("location : index.php");
    //         die();
    //     }
    // }

    $_SESSION['LAST_ACTIVE_TIME'] = time();

    if(!isset($_SESSION['IS_LOGIN'])){
      header('location: index.php', true);
      die();
    }

    include "config.php";

    if ($_SERVER['REQUEST_METHOD']=='POST'){

        $name = mysqli_real_escape_string($con, $_POST['name']);
        $position = mysqli_real_escape_string($con, $_POST['position']);
        $office = mysqli_real_escape_string($con, $_POST['office']);
        $age = mysqli_real_escape_string($con, $_POST['age']);
        $startdate = mysqli_real_escape_string($con, $_POST['startdate']); 
        $company = mysqli_real_escape_string($con, $_POST['company']);
        $salary = mysqli_real_escape_string($con, $_POST['salary']);

        if(!isset($name) || $name == '' || !isset($position) || $position == '' || !isset($office) || $office == '' || !isset($age) || $age == ''|| !isset($startdate) || $startdate == ''|| !isset($company) || $company == ''|| !isset($salary) || $salary == ''){

            echo "<script>alert('Please Fillup All Blocks');</script>";
        }
        else{

            $sql = "INSERT INTO `employee` (`name`, `position`, `office`, `age`, `startdate`, `company`, `salary`) VALUES ('$name', '$position', '$office', '$age', '$startdate', '$company', '$salary');";
            
            $query = mysqli_query($con, $sql);

            if(isset($query)){
                echo "<script>alert('Record Updated Successfully');</script>";
            }
            else{
                echo "<script>alert('Connection Failed');</script>";
            }
    }

  }

?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Profile - Brand</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i">
    <link rel="stylesheet" href="assets/fonts/fontawesome-all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
</head>

<body id="page-top">
    <div id="wrapper">
        <?php include "components/navbar.php"; ?>
        <div class="d-flex flex-column" id="content-wrapper">
            <div id="content">
                <nav class="navbar navbar-light navbar-expand bg-white shadow mb-4 topbar static-top">
                    <div class="container-fluid"><button class="btn btn-link d-md-none rounded-circle mr-3" id="sidebarToggleTop" type="button"><i class="fas fa-bars"></i></button>
                        
                    </div>
            </nav>
            <div class="container-fluid">
                <h3 class="text-dark mb-4">Add Employees</h3>
                <div class="row mb-3">
                    <div class="col-lg-8">
                        <div class="row mb-3 d-none">
                            <div class="col">
                                <div class="card text-white bg-primary shadow">
                                    <div class="card-body">
                                        <div class="row mb-2">
                                            <div class="col">
                                                <p class="m-0">Peformance</p>
                                                <p class="m-0"><strong>65.2%</strong></p>
                                            </div>
                                            <div class="col-auto"><i class="fas fa-rocket fa-2x"></i></div>
                                        </div>
                                        <p class="text-white-50 small m-0"><i class="fas fa-arrow-up"></i>&nbsp;5% since last month</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col">
                                <div class="card text-white bg-success shadow">
                                    <div class="card-body">
                                        <div class="row mb-2">
                                            <div class="col">
                                                <p class="m-0">Peformance</p>
                                                <p class="m-0"><strong>65.2%</strong></p>
                                            </div>
                                            <div class="col-auto"><i class="fas fa-rocket fa-2x"></i></div>
                                        </div>
                                        <p class="text-white-50 small m-0"><i class="fas fa-arrow-up"></i>&nbsp;5% since last month</p>
                                    </div>
                                </div>
                            </div>
                        </div>
        <div class="row">
            <div class="col">
                <div class="card shadow mb-3">
                    <div class="card-header py-3">
                        <p class="text-primary m-0 font-weight-bold">User Settings</p>
                    </div>
                    <div class="card-body">
                    <form action="addemp.php" method="POST">
                    <!-- <img class="mb-4" src="/docs/5.2/assets/brand/bootstrap-logo.svg" alt="" width="72" height="57"> -->

                    <div class="form-floating mt-2">
                      <input type="name" class="form-control" id="floatingInput" placeholder="Name" name="name">
                      <label for="floatingInput">Name</label>
                    </div>

                    <div class="form-floating mt-2">
                      <input type="position" class="form-control" id="floatingInput" placeholder="position" name="position">
                      <label for="floatingInput">Position</label>
                    </div>

                    <div class="form-floating mt-2">
                      <input type="office" class="form-control" id="floatingInput" placeholder="office" name="office">
                      <label for="floatingInput">Office</label>
                    </div>

                    <div class="form-floating mt-2">
                      <input type="age" class="form-control" id="floatingInput" placeholder="age" name="age">
                      <label for="floatingInput">Age</label>
                    </div>

                     <div class="form-floating mt-2">
                      <input type="startdate" class="form-control" id="floatingInput" placeholder="startdate" name="startdate">
                      <label for="floatingInput">Startdate</label>
                    </div>

                    <div class="form-floating mt-2">
                      <input type="company" class="form-control" id="floatingInput" placeholder="company" name="company">
                      <label for="floatingInput">Company</label>
                    </div>

                     <div class="form-floating mt-2">
                      <input type="salary" class="form-control" id="floatingInput" placeholder="salary" name="salary">
                      <label for="floatingInput">Salary</label>
                    </div>

                    <div class="checkbox mb-3">
                      
                    </div>
                    <button class="w-100 btn btn-lg btn-primary" type="submit">Submit</button>
                  </form>
                    </div>
                </div>
            
            </div>
        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div><a class="border rounded d-inline scroll-to-top" href="#page-top"><i class="fas fa-angle-up"></i></a></div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/chart.min.js"></script>
    <script src="assets/js/bs-init.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.js"></script>
    <script src="assets/js/theme.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
</body>

</html>

