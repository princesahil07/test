<?php
	if(isset($_POST['submit'])){
		$name = $_POST['name'];

		if(isset($_FILES['pdf_file']['name'])){
			$file_name = $_FILES['pdf_file']['name'];
			$file_temp = $_FILES['pdf_file']['file_temp'];

			move_uploaded_file($file_temp, "./pdf/".$file_name);
			$insertquery = "INSERT INTO pdf_data(username , filename) VALUES ('$name', '$file_name')";
			$query = mysqli_query($con, $insertquery);
		}
		else{
			echo "
				<script>
					alert('File Must Be Upload in PDF formate');
				</script>
			";
		}
	}
?>

<form action="uploadpdf.php" method="POST" enctype="multipart/form-data">
	<div class=""></div>
</form>