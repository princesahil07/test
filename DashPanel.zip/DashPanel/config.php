<?php

	$hostname = "localhost";
	$username = "root";
	$password = "";
	$db_name = "dashpanel";

	$con = mysqli_connect($hostname, $username, $password, $db_name) or die('Failed To Connect');

?>